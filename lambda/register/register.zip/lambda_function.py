# Authors: Antonio Cabrera y Alejandro Gómez

import sys
import logging
import pymysql
import json
import base64
import uuid
import crypt
from datetime import date
from datetime import timedelta
from datetime import datetime
from urllib.parse import parse_qs

# Información de la base de datos
rds_host = "3.211.29.216"
username = "admin"
password = "password"
dbname = "Twitter"

def lambda_handler(event , context):
    
    if(event == None):
        return {
            'statusCode': 400,
            'headers': { 'Access-Control-Allow-Origin' : '*' },
            'body' : "Error: No se ha enviado ningún evento"
        }
    
    body = eval(event["body"])

    # Comprobamos que se han enviado los parámetros necesarios
    
    if(body == None):
        return {
            'statusCode': 400,
            'headers': { 'Access-Control-Allow-Origin' : '*' },
            'body' : "Error: No se ha enviado el body"
        }

    keys = ["username", "password"]

    if(not all (key in body for key in keys)):
        return {
            'statusCode': 400,
            'headers': { 'Access-Control-Allow-Origin' : '*' },
            'body' : "Error: No se han enviado todos los parámetros"
        }

    # Obtenemos los parámetros
    username = body["username"]
    password = body["password"]
   
    conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)

    # Comprobamos que el usuario no existe (si existe, no se puede registrar)
    
    with conn.cursor() as cur:
        cur.execute("SELECT * FROM Users WHERE username = %s", (username))
        user = cur.fetchone()
        conn.commit()
    
        if(user != None):
            return {
                'statusCode': 400,
                'headers': { 'Access-Control-Allow-Origin' : '*' },
                'body' : "Error: El usuario ya existe"
            }
        else:
            # Creamos el usuario
            
            # Obtenemos la id del usuario
            cur.execute("SELECT MAX(id) FROM Users")
            id = cur.fetchone()[0] + 1
            conn.commit()

            # Generamos el hash de la contraseña
            hash = crypt.crypt(password, 'salt')

            # Generamos el ssid
            ssid = str(uuid.uuid4())

            # Generamos el userId
            userId = str(uuid.uuid4())

            # Generamos la fecha de creación
            creationDate = datetime.now()

            # Generamos la fecha de expiración
            expirationDate = creationDate + timedelta(days=1)

    # Devolvemos el ssid y el userId
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body' : json.dumps( { 'res':res , 'msg':msg , 'user':user, 'ssid':ssid, 'userId':userId, 'userBlocked':blocked ,'avatar':avatar})
    }
